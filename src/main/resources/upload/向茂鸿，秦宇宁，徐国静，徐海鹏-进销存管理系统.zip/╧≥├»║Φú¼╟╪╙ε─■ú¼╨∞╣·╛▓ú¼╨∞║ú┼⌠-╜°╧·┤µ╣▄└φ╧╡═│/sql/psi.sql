create table billin_goods
(
    bi_id       int auto_increment
        primary key,
    bi_name     varchar(20)   null,
    bi_desc     varchar(20)   null,
    bi_date     date          null,
    bi_allmoney double        null,
    in_state    int default 0 null,
    supplier_id int           not null,
    depot_id    int           not null
);

create table billout_goods
(
    bo_id       int auto_increment
        primary key,
    bo_name     varchar(20)   null,
    bo_desc     varchar(20)   null,
    bo_date     date          null,
    bo_allmoney double        null,
    client_id   int           not null,
    out_state   int default 0 not null,
    depot_id    int           not null
);

create table classify
(
    cls_id     int auto_increment comment '分类id'
        primary key,
    cls_name   varchar(20)  null comment '分类名称',
    cls_desc   varchar(100) null comment '分类描述',
    cls_remark varchar(200) null comment '备注',
    depot_id   int          not null
);

create table client
(
    id             int auto_increment
        primary key,
    client_name    varchar(20)               null,
    client_money   double default 2147483647 null,
    client_phone   int                       null,
    client_address varchar(100)              null,
    state          int    default 0          not null
);

create table client_goods
(
    cg_id         int auto_increment comment '商品id'
        primary key,
    cg_name       varchar(20) null comment '商品名称',
    cg_desc       varchar(20) null comment '商品分类,此列关联分类表主键id',
    cg_num        int         null comment '商品数量',
    cg_price      double      null comment '商品单价',
    cg_totalPrice double      null comment '商品总价',
    client_id     int         not null
);

create table client_putin
(
    in_id        int auto_increment
        primary key,
    igoods_name  varchar(20)   null,
    igoods_desc  varchar(20)   null,
    igoods_num   int           null,
    igoods_price double        null,
    igoods_date  date          null,
    state        int default 0 null,
    orderNumber  varchar(50)   null,
    client_id    int           not null,
    depot_id     int           not null
);

create table finance
(
    id            int                       not null
        primary key,
    depot_name    varchar(255)              null,
    money         double default 2147531647 null,
    depot_number  varchar(100)              null,
    depot_address varchar(200)              null,
    depot_phone   int                       null,
    depot_bank    varchar(100)              null,
    depot_account varchar(50)               null
);

create table goods
(
    go_id         int         not null comment '商品id',
    go_name       varchar(20) null comment '商品名称',
    go_desc       varchar(20) null comment '商品分类,此列关联分类表主键id',
    go_num        int         null comment '商品数量',
    go_price      double      null comment '商品单价',
    go_totalPrice double      null comment '商品总价',
    depot_id      int         not null
);

create table putin_goods
(
    in_id        int         not null comment '入库商品的序号,目前只是一条记录'
        primary key,
    igoods_name  varchar(20) null comment '商品名称',
    igoods_desc  varchar(20) null comment '商品分类',
    igoods_num   int         null comment '入库数量',
    igoods_date  date        null comment '入库日期',
    igoods_price double      null,
    orderNumber  varchar(50) null,
    state        int         null,
    supplier_id  int         not null,
    depot_id     int         not null
);

create table putout_goods
(
    out_id      int auto_increment comment '出库商品的序号,目前只是一条记录'
        primary key,
    ogoods_name varchar(20)   null comment '商品名称',
    ogoods_desc varchar(20)   null comment '商品分类',
    ogoods_num  int           null comment '出库数量',
    ogoods_date date          null comment '出库日期',
    price       double        null,
    orderNumber varchar(50)   null,
    state       int default 0 null,
    go_id       int           null,
    client_id   int           not null,
    depot_id    int           not null
);

create table supplier
(
    sl_id            int                       not null comment '供应商ID'
        primary key,
    sl_name          varchar(255)              not null comment '供应商名字',
    sl_money         double default 2147483647 not null comment '供应商金额',
    supplier_number  varchar(100)              not null,
    supplier_address varchar(200)              not null,
    supplier_phone   int                       not null,
    supplier_bank    varchar(100)              not null,
    supplier_account varchar(50)               not null,
    state            int    default 0          not null
)
    comment '纳税人识别号';

create table supplier_outgoods
(
    out_id       int auto_increment
        primary key,
    ogoods_name  varchar(20)   null,
    ogoods_desc  varchar(20)   null,
    ogoods_num   int           null,
    ogoods_price double        null,
    ogoods_date  date          null,
    state        int default 0 null,
    orderNumber  varchar(50)   null,
    supplier_id  int           not null,
    depot_id     int           not null
);

create table user
(
    id       int auto_increment
        primary key,
    username varchar(20) null,
    password varchar(20) null,
    role     int         null
);

create table warning
(
    war_id     int auto_increment
        primary key,
    war_name   varchar(20)  null,
    war_desc   varchar(20)  null,
    war_remark varchar(250) null,
    war_num    int          null,
    depot_id   int          not null
);

